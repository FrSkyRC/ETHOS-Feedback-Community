var searchData=
[
  ['black_0',['BLACK',['../classbase.html#a70e0b80c5194c3c6039e716ab82fa93f',1,'base']]],
  ['blue_1',['BLUE',['../classbase.html#aa5516fbf67aa356444878a8eb9bb3b21',1,'base']]]
];
