var searchData=
[
  ['yellow_0',['YELLOW',['../classbase.html#a7b1e441ab6630e47792b580605852dde',1,'base']]]
];
