var searchData=
[
  ['magenta_0',['MAGENTA',['../classbase.html#aaa5f2c478172e85be33891fae2e9a77a',1,'base']]],
  ['main_5fvoltage_1',['MAIN_VOLTAGE',['../classbase.html#a32d7e6a1d73e35d30e731cbb9c5f0bd8',1,'base']]]
];
