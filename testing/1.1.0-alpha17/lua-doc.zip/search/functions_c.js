var searchData=
[
  ['name_0',['name',['../classCurve.html#afff82210632b292e354922c2c137c679',1,'Curve::name()'],['../classmodel.html#adabd4a53982f2e9c4fdfc25ba1fcadb2',1,'model::name()'],['../classSource.html#ae53981806f2449c6fe50c6239d210db4',1,'Source::name()'],['../classTimer.html#a896d1e4de53a0be97863a49b1f4f0425',1,'Timer::name()']]]
];
