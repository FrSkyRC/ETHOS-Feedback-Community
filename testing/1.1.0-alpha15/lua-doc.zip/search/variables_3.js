var searchData=
[
  ['dotted_0',['DOTTED',['../classbase.html#af31531e81163d0098c3d9046c809afcd',1,'base']]]
];
