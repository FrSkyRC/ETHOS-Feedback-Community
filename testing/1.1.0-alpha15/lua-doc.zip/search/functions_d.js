var searchData=
[
  ['offset_0',['offset',['../classCurve.html#a2d49e99aa616926e4b9571062071f4fe',1,'Curve']]],
  ['opendialog_1',['openDialog',['../classform.html#ad0172af37e733b3e9ecfcc296f30deef',1,'form']]]
];
