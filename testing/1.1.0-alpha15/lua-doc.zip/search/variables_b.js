var searchData=
[
  ['red_0',['RED',['../classbase.html#acd34d8dc53aa869ccfc3e34fb7387c19',1,'base']]],
  ['right_1',['RIGHT',['../classbase.html#a8ce7f265326523133e0a615e31048fc2',1,'base']]],
  ['rssi_5flow_2',['RSSI_LOW',['../classbase.html#a3307c973f814e7d7f13adf9e8a63e2ad',1,'base']]],
  ['rtc_5fvoltage_3',['RTC_VOLTAGE',['../classbase.html#afa9b98964a81c0299149655045331294',1,'base']]]
];
