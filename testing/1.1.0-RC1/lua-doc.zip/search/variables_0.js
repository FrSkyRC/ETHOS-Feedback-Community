var searchData=
[
  ['analog_5ffirst_5fpot_0',['ANALOG_FIRST_POT',['../classbase.html#ab4564458f4b1afa78c3c8e3e830c11bd',1,'base']]],
  ['analog_5ffirst_5fslider_1',['ANALOG_FIRST_SLIDER',['../classbase.html#a84a4045a71289ac34b83904968ea2549',1,'base']]],
  ['audio_5fbeep_2',['AUDIO_BEEP',['../classbase.html#ab8ca4d154272d83141dacdf2a17920c4',1,'base']]],
  ['audio_5fmute_3',['AUDIO_MUTE',['../classbase.html#a507dfe81b537a92e1f457e0beb8d88ae',1,'base']]],
  ['audio_5fvoice_4',['AUDIO_VOICE',['../classbase.html#a675c2050bd3675c3f7a444a517f5db9c',1,'base']]]
];
