var searchData=
[
  ['x_5fabs_0',['X_ABS',['../classbase.html#a99d09a29f9acb58c3d811b84ed318d0a',1,'base']]],
  ['x_5fnegative_1',['X_NEGATIVE',['../classbase.html#a28508b2aa167b0aecf43268d5081b971',1,'base']]]
];
