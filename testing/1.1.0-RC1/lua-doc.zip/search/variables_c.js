var searchData=
[
  ['solid_0',['SOLID',['../classbase.html#a325070d8c41c4ad0be6e86db0e10ee88',1,'base']]],
  ['stashed_1',['STASHED',['../classbase.html#aba9eaba539c9832fef33a84809061523',1,'base']]]
];
