var searchData=
[
  ['white_0',['WHITE',['../classbase.html#afd14aeac1131195f90c361e9348684aa',1,'base']]]
];
