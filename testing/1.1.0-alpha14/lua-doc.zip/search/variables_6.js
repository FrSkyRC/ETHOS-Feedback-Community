var searchData=
[
  ['green_0',['GREEN',['../classbase.html#ac00eeea5a50e64353e682d1449b05a7e',1,'base']]]
];
