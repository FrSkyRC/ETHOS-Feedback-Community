var searchData=
[
  ['latitude_0',['LATITUDE',['../classbase.html#ab38381c7f7a735544a4514d16db13d6e',1,'base']]],
  ['left_1',['LEFT',['../classbase.html#a650ea5182a7ac42913c8a566286ae9e2',1,'base']]],
  ['longitude_2',['LONGITUDE',['../classbase.html#adbc9859d55f58dfcebc9ef8e8c4da432',1,'base']]]
];
