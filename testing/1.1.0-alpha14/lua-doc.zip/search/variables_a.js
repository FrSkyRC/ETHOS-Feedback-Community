var searchData=
[
  ['orange_0',['ORANGE',['../classbase.html#adfdfebf17de6a3232439b3aa019bee9d',1,'base']]]
];
