var searchData=
[
  ['key_5fpage_5fdown_0',['KEY_PAGE_DOWN',['../classbase.html#aa3a5a5f799a2ea27215925ff04812d23',1,'base']]],
  ['key_5fpage_5fup_1',['KEY_PAGE_UP',['../classbase.html#ac00b7240945472f0f0761c41c3a1520a',1,'base']]]
];
