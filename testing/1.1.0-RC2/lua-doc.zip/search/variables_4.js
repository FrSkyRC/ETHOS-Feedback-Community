var searchData=
[
  ['evt_5fkey_0',['EVT_KEY',['../classbase.html#adb9021a0e845a9f3af7b6c2054d01c28',1,'base']]],
  ['evt_5ftouch_1',['EVT_TOUCH',['../classbase.html#aebd0e63c169d79005841affb683f49ce',1,'base']]]
];
