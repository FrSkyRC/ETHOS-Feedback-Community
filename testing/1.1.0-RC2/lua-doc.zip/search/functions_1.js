var searchData=
[
  ['band_0',['band',['../classLuaSensor.html#ae13f0e6377f987334b062b06ebb0be73',1,'LuaSensor::band()'],['../classLuaSportFrame.html#a3e340768be57b597c6805161e6bb7fbf',1,'LuaSportFrame::band()']]],
  ['bitmap_1',['bitmap',['../classmodel.html#a097faac804830f183e329bc3c0dfa14d',1,'model']]]
];
