var searchData=
[
  ['left_0',['LEFT',['../classbase.html#a650ea5182a7ac42913c8a566286ae9e2',1,'base']]]
];
