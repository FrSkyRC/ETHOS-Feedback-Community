var searchData=
[
  ['themecolor_0',['themeColor',['../classlcd.html#a3b9d4962f02d1259e3da9c003d4d495b',1,'lcd']]],
  ['type_1',['type',['../classCurve.html#aa9cb80111c5fd9836ac833d51854d97a',1,'Curve']]]
];
