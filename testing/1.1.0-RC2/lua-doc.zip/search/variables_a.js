var searchData=
[
  ['option_5fcell_5fcount_0',['OPTION_CELL_COUNT',['../classbase.html#aeecb3b53f55b866958fb96c0656d2624',1,'base']]],
  ['option_5fcell_5fhighest_1',['OPTION_CELL_HIGHEST',['../classbase.html#a7e355a17de2a9a279107e18d7d370f7f',1,'base']]],
  ['option_5fcell_5flowest_2',['OPTION_CELL_LOWEST',['../classbase.html#a4c93e409d61ecdd1cb04f5acba7531a3',1,'base']]],
  ['option_5flatitude_3',['OPTION_LATITUDE',['../classbase.html#a115a886f2f3960cdd560e76207e2fc6b',1,'base']]],
  ['option_5flongitude_4',['OPTION_LONGITUDE',['../classbase.html#a04afab347038426b5db814b8b5d78e28',1,'base']]],
  ['orange_5',['ORANGE',['../classbase.html#adfdfebf17de6a3232439b3aa019bee9d',1,'base']]]
];
