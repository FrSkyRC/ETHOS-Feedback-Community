This folder stores compiled cache files.

Please do not delete it.

--

To force a recompile of the app; simply delete all the files ending in .luac